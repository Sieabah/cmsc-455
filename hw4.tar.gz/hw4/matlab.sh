matlab -nodesktop -nosplash -nojvm -r "pgrank.m;"
